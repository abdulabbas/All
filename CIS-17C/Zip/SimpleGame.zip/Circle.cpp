#include "Circle.h"
#include <iostream>

void Circle::draw() {
	std::cout << "0";
}