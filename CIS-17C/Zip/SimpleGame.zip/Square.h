#pragma once

#include "GameObject.h"

class Square : public GameObject {
public:
	void draw();
};