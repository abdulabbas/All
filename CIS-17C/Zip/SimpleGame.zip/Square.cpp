#include "Square.h"
#include <iostream>

void Square::draw() {
	std::cout << "|_|";
}