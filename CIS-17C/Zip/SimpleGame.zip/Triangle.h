#pragma once

#include "GameObject.h"

class Triangle : public GameObject {
public:
	void draw();
};