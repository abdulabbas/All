#include "Triangle.h"
#include <iostream>

void Triangle::draw() {
	std::cout << "/\\";
}