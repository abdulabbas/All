#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H

class GameObject {
	virtual void draw() = 0;
};

#endif