#include <iostream>
#include "Circle.h"
#include "Square.h"
#include "Triangle.h"

int main() {
	Circle *c;
	Square *s;
	Triangle *t;
	c = new Circle();
	s = new Square();
	t = new Triangle();
	t->draw();
	s->draw();
	c->draw();
	int i = 0;
	std::cin >> i;
}