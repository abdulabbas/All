#pragma once
#include "GameObject.h"

class Circle : public GameObject {
public:
	void draw();
};